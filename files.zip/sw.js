const CACHE_NAME = 'integral-vet-v1';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './icon-512-maskable.png'
];

self.addEventListener('install', function(event){
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache){
      return cache.addAll(APP_SHELL);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(k){ return k !== CACHE_NAME; })
            .map(function(k){ return caches.delete(k); })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', function(event){
  const req = event.request;
  const url = new URL(req.url);

  // Only handle our own app-shell files with cache-first.
  // Everything else (Firebase Auth/Firestore, Google APIs, etc.) goes straight to the network
  // so those libraries can manage their own offline queueing.
  if(url.origin === self.location.origin){
    event.respondWith(
      caches.match(req).then(function(cached){
        const network = fetch(req).then(function(res){
          if(res && res.status === 200){
            const copy = res.clone();
            caches.open(CACHE_NAME).then(function(cache){ cache.put(req, copy); });
          }
          return res;
        }).catch(function(){ return cached; });
        return cached || network;
      })
    );
  }
});
